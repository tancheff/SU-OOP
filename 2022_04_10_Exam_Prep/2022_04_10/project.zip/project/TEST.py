list_a = [1, 2, 3, 4, 5]

b = list_a.pop(3)

print(b)
print(list_a)